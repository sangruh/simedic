/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: admin_simedic
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_agenda`
--

DROP TABLE IF EXISTS `tbl_agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_agenda` (
  `id_ag` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(1000) NOT NULL,
  `lokasi` varchar(1000) NOT NULL,
  `tgl` date NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_ag`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_agenda`
--

LOCK TABLES `tbl_agenda` WRITE;
/*!40000 ALTER TABLE `tbl_agenda` DISABLE KEYS */;
INSERT INTO `tbl_agenda` VALUES (1,'BAMBU RAMPAL','SUMBERMUJUR','2022-09-06',0,'0000-00-00 00:00:00'),(2,'BAMBU APUS','SUMBERMUJUR','2022-09-07',0,'0000-00-00 00:00:00'),(3,'BAMBU AMPEL','SUMBERMUJUR','2022-09-08',0,'0000-00-00 00:00:00'),(4,'BAMBU NAGIN','SUMBERMUJUR','2022-09-10',0,'0000-00-00 00:00:00'),(5,'BAMBU ORI','SUMBERMUJUR','2022-09-12',0,'0000-00-00 00:00:00'),(6,'BAMBU PETUNG','SUMBERMUJUR','2022-09-14',0,'0000-00-00 00:00:00'),(7,'BAMBU TULUP','SUMBERMUJUR','2022-09-19',0,'0000-00-00 00:00:00'),(8,'BAMBU TUTUL','SUMBERMUJUR','2022-09-16',0,'0000-00-00 00:00:00'),(9,'BAMBU WULUNG','SUMBERMUJUR','2022-09-17',0,'0000-00-00 00:00:00'),(10,'BAMBU JAJANG','SUMBERMUJUR','2022-09-15',0,'0000-00-00 00:00:00'),(11,'MELATI','PENANGGAL','2022-09-08',0,'0000-00-00 00:00:00'),(12,'ANYELIR 2','PENANGGAL','2022-09-09',0,'0000-00-00 00:00:00'),(13,'KENANGA 2','PENANGGAL','2022-09-16',0,'0000-00-00 00:00:00'),(14,'MAWAR','PENANGGAL','2022-09-12',0,'0000-00-00 00:00:00'),(15,'ANYELIR 1','PENANGGAL','2022-09-13',0,'0000-00-00 00:00:00'),(16,'BOUGENVILLE','PENANGGAL','2022-09-14',0,'0000-00-00 00:00:00'),(17,'ANGGREK','PENANGGAL','2022-09-15',0,'0000-00-00 00:00:00'),(18,'KENANGA 1','PENANGGAL','2022-09-19',0,'0000-00-00 00:00:00'),(19,'SEDAP MALAM','PENANGGAL','2022-09-21',0,'0000-00-00 00:00:00'),(20,'DELIMA','PENANGGAL','2022-09-20',0,'0000-00-00 00:00:00'),(21,'SERUNI','PENANGGAL','2022-09-22',0,'0000-00-00 00:00:00'),(22,'CEMPAKA','PENANGGAL','2022-09-23',0,'0000-00-00 00:00:00'),(23,'DURIAN','TAMBAHREJO','2022-09-14',0,'0000-00-00 00:00:00'),(24,'KELENGKENG','TAMBAHREJO','2022-09-05',0,'0000-00-00 00:00:00'),(25,'MELATI','TAMBAHREJO','2022-09-02',0,'0000-00-00 00:00:00'),(26,'DAHLIA','TAMBAHREJO','2022-09-12',0,'0000-00-00 00:00:00'),(27,'KENANGA','TAMBAHREJO','2022-09-06',0,'0000-00-00 00:00:00'),(28,'DOMPYONG','TAMBAHREJO','2022-09-09',0,'0000-00-00 00:00:00'),(29,'RAMBUTAN','TAMBAHREJO','2022-09-08',0,'0000-00-00 00:00:00'),(30,'KELAPA','KLOPOSAWIT','2022-09-05',0,'0000-00-00 00:00:00'),(31,'ANGGUR','KLOPOSAWIT','2022-09-09',0,'0000-00-00 00:00:00'),(32,'GELATIK','KLOPOSAWIT','2022-09-08',0,'0000-00-00 00:00:00'),(33,'PIPIT','KLOPOSAWIT','2022-09-13',0,'0000-00-00 00:00:00'),(34,'DELIMA','KLOPOSAWIT','2022-09-12',0,'0000-00-00 00:00:00'),(35,'ANGGREK','KLOPOSAWIT','2022-09-14',0,'0000-00-00 00:00:00'),(36,'MERPATI','KLOPOSAWIT','2022-09-16',0,'0000-00-00 00:00:00'),(37,'SERUNI','TUMPENG','2022-09-05',0,'0000-00-00 00:00:00'),(38,'NUSA INDAH I','TUMPENG','2022-09-08',0,'0000-00-00 00:00:00'),(39,'KENANGA','TUMPENG','2022-09-12',0,'0000-00-00 00:00:00'),(40,'MELATI','TUMPENG','2022-09-14',0,'0000-00-00 00:00:00'),(41,'MAWAR','TUMPENG','2022-09-19',0,'0000-00-00 00:00:00'),(42,'NUSA INDAH II','TUMPENG','2022-09-20',0,'0000-00-00 00:00:00'),(43,'Pemberian Obat Cacing','SDN SUMBERMUJUR 01 SUMBERMUJUR, Dsn Krajan Desa Sumbermujur','2022-08-01',1,'2022-09-30 11:51:06'),(44,'SDN SUMBERMUJUR 02','SUMBERMUJUR','2022-08-25',0,'0000-00-00 00:00:00'),(45,'SDN SUMBERMUJUR 03','SUMBERMUJUR','2022-08-29',0,'0000-00-00 00:00:00'),(46,'SDN SUMBERMUJUR 04','SUMBERMUJUR','2022-08-29',0,'0000-00-00 00:00:00'),(47,'SDN SUMBERMUJUR 05','SUMBERMUJUR','2022-08-25',0,'0000-00-00 00:00:00'),(48,'SDN PENANGGAL 01','PENANGGAL','2022-08-04',0,'0000-00-00 00:00:00'),(49,'SDN PENANGGAL 02','PENANGGAL','2022-08-05',0,'0000-00-00 00:00:00'),(50,'SDN PENANGGAL 03','PENANGGAL','2022-08-05',0,'0000-00-00 00:00:00'),(51,'SDN PENANGGAL 04','PENANGGAL','2022-08-04',0,'0000-00-00 00:00:00'),(52,'SDN PENANGGAL 05','PENANGGAL','2022-08-02',0,'0000-00-00 00:00:00'),(53,'MI NURIS PENANGGAL','PENANGGAL','2022-08-02',0,'0000-00-00 00:00:00'),(54,'SDN TAMBAHREJO 01','TAMBAHREJO','2022-08-16',0,'0000-00-00 00:00:00'),(55,'SDN TAMBAHREJO 02','TAMBAHREJO','2022-08-16',0,'0000-00-00 00:00:00'),(56,'SDN TAMBAHREJO 03','TAMBAHREJO','2022-08-18',0,'0000-00-00 00:00:00'),(57,'SDN KLOPOSAWIT 01','KLOPOSAWIT','2022-08-22',0,'0000-00-00 00:00:00'),(58,'SDN KLOPOSAWIT 02','KLOPOSAWIT','2022-08-23',0,'0000-00-00 00:00:00'),(59,'SDN KLOPOSAWIT 03','KLOPOSAWIT','2022-08-24',0,'0000-00-00 00:00:00'),(60,'SDN TUMPENG 01','TUMPENG','2022-08-24',0,'0000-00-00 00:00:00'),(61,'SDN TUMPENG 02','TUMPENG','2022-08-24',0,'0000-00-00 00:00:00'),(62,'SDN TUMPENG 03','TUMPENG','2022-08-25',0,'0000-00-00 00:00:00'),(63,'MI TUMPENG ','TUMPENG','2022-08-25',0,'0000-00-00 00:00:00'),(65,'Pemeriksaan Kesehatan Umum dan Gigi','LOKASI HUNTAP DESA SUMBERMUJUR','2022-10-22',1,'2022-10-10 01:34:30'),(67,'POSYANDU','Posyandu Bambu Rampal Dusun Kebonseket Desa Sumbermujur','2022-10-06',1,'2022-10-06 10:57:26'),(68,'POSYANDU','BAMBU PETUNG, SIDOREJO TIMUR DESA SUMBERMUJUR','2022-10-13',1,'2022-10-13 03:31:10'),(69,'POSYANDU','POSYANDU BAMBU TULIP, SIDOREJO BARAT DESA SUMBERMUJUR','2022-10-19',1,'2022-10-13 03:33:18'),(70,'POSYANDU','POSYANDU BAMBU WULUNG, UMBULSARI DESA SUMBERMUJUR','2022-10-17',1,'2022-10-13 03:34:10'),(71,'POSYANDU','Pustu Mahameru Huntap, Sumbermujur','2022-10-18',1,'2022-10-17 02:38:00'),(72,'Pertemuan Kelompok Masyarakat Peduli Kesehatan (KMPK)','Puskesmas Penanggal','2022-10-20',1,'2022-10-20 00:15:06'),(73,'Dokter Muter','Pustu Mahameru Huntap, Sumbermujur','2022-11-29',1,'2022-11-28 23:12:33'),(74,'Kunjungan Konseling Kesehatan','Desa Kloposawit','2022-12-06',1,'2022-12-02 07:35:28'),(75,'Kunjungan Konseling Kesehatan','Desa Kloposawit','2022-12-08',1,'2022-12-02 07:36:59'),(76,'Kunjungan Konseling Kesehatan','Desa Tambahrejo','2022-12-06',1,'2022-12-02 07:37:49'),(77,'Kunjungan Konseling Kesehatan','Desa Tambahrejo','2022-12-15',1,'2022-12-02 07:38:39'),(78,'Kunjungan Konseling Kesehatan','Desa Tambahrejo','2022-12-09',1,'2022-12-02 07:39:07'),(79,'Kunjungan Konseling Kesehatan','Desa Tambahrejo','2022-12-15',1,'2022-12-02 07:39:20'),(80,'Kunjungan Konseling Kesehatan','Desa Tambahrejo','2022-12-16',1,'2022-12-02 07:39:28'),(81,'Kunjungan Konseling Kesehatan','Desa Sumbermujur','2022-12-15',1,'2022-12-02 07:39:53'),(82,'Kunjungan Konseling Kesehatan','Desa Tambahrejo','2022-12-08',1,'2022-12-02 07:40:19'),(83,'Kunjungan Konseling Kesehatan','Desa Tumpeng','2022-12-06',1,'2022-12-02 07:40:33'),(84,'Kunjungan Konseling Kesehatan','Desa Tumpeng','2022-12-08',1,'2022-12-02 07:40:50'),(85,'Kunjungan Konseling Kesehatan','Desa Kloposawit','2022-12-02',1,'2022-12-02 07:45:09'),(86,'KEGIATAN MAHAMERU CARE MOBILE','BUMI SEMERU DAMAI HUNTAP SUMBERMUJUR','2022-12-21',1,'2022-12-21 07:36:07'),(87,'Dokter Muter','Balai Pertemuan Fasos 2','2023-05-31',1,'2023-05-30 07:37:44');
/*!40000 ALTER TABLE `tbl_agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_evakuasi`
--

DROP TABLE IF EXISTS `tbl_evakuasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_evakuasi` (
  `id_ev` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(1000) NOT NULL,
  `alamat` varchar(1000) NOT NULL,
  `lat` varchar(1000) NOT NULL,
  `lng` varchar(1000) NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_ev`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_evakuasi`
--

LOCK TABLES `tbl_evakuasi` WRITE;
/*!40000 ALTER TABLE `tbl_evakuasi` DISABLE KEYS */;
INSERT INTO `tbl_evakuasi` VALUES (1,'Masjid Khusnul Khotimah LTM.NU','V283+X85, Umbulrejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.130640892151634',' 113.00312089253175 ',0,'0000-00-00 00:00:00'),(2,'Masjid Baitur Rohman','V264+PVR, Sumbermujur, Candipuro, Umbulsari, Sumbermujur, Lumajang, Kabupaten Lumajang, Jawa Timur 67373',' -8.1362487363709',' 113.00698327326084 ',1,'2022-10-03 08:35:26'),(3,'Masjid Al Kautsar','V257+X6X, Umbulsari, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.137863101327206',' 113.01350640580374 ',0,'0000-00-00 00:00:00'),(4,'Masjid BAITURAHMAN GELAPAN','V2FG+329, Sidorejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.124948000492314',' 113.02526520935683 ',0,'0000-00-00 00:00:00'),(5,'Masjid AT TAQWA LTM.NU','V229+9FG, Unnamed Road, Kebonseket Sumbermujur, Candipuro, Lumajang Regency, East Java 67373',' -8.146804347005105',' 113.01914555126118 ',0,'0000-00-00 00:00:00'),(6,'Masjid Al Ikhlas LTM.NU','V26C+HF7, Jl. Pancasila, Banjarrejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.136693443324253',' 113.02129131884878 ',0,'0000-00-00 00:00:00'),(7,'MASJID ROUDOTUL MUSTOFA PENANGGAL','V25P+Q7X, Watu Kandang, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.138477738902532',' 113.03639751978514 ',0,'0000-00-00 00:00:00'),(8,'MASJID BANJARREJO','Banjarrejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.135330594945943',' 113.02913376418432 ',0,'0000-00-00 00:00:00'),(9,'Masjid An Nur Penanggal','V24V+R39, Krajan, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.142760851726857',' 113.04278420592985 ',0,'0000-00-00 00:00:00'),(10,'Masjid AL-IKHLASH','V343+WV3, Dsn Rekesan Timur,, Rekasan Timur, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.142569452804343',' 113.05463235544815 ',0,'0000-00-00 00:00:00'),(11,'Masjid Ar Ridho LTM.NU','V346+F2P, Jl. Dusun Rekesan, Rekasan, Tambahrejo, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.143593524974072',' 113.06005034782116 ',0,'0000-00-00 00:00:00'),(12,'Masjid Al Kautsar Tambahrejo','V329+956, Krajan, Tambahrejo, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.1489774','113.0678504',0,'2022-10-03 06:31:24'),(13,'SDN SUMBERMUJUR 01','V26C+MPW, Krajan, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.13818501397565',' 113.02182778710115 ',0,'0000-00-00 00:00:00'),(14,'SDN SUMBERMUJUR 02','V2FC+8GJ, Sidorejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.12647697089345',' 113.02120267975214 ',0,'0000-00-00 00:00:00'),(15,'SDN SUMBERMUJUR 03','V278+HQC, Jl. Kalpataru I, Umbulrejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.13591164440336',' 113.0169074452398 ',0,'0000-00-00 00:00:00'),(16,'SDN SUMBERMUJUR 04','V282+3FJ, Wonorenggo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.13442841074933',' 113.0010935841203 ',0,'0000-00-00 00:00:00'),(17,'SDN SUMBERMUJUR 05','Kebonseket, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.149231346902045',' 113.0186597851598 ',0,'0000-00-00 00:00:00'),(18,'SMP Negeri 5 Candipuro','V269+5M7, Banjarrejo, Sumbermujur, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.139509758274675',' 113.01916048968788 ',0,'0000-00-00 00:00:00'),(19,'SDN PENANGGAL 01','V24V+J63, Krajan, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.14297300123496',' 113.04294644660906 ',0,'0000-00-00 00:00:00'),(20,'SDN PENANGGAL 02','Jl. Merdeka, Banjarrejo, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.138767195931685',' 113.03000747066184 ',0,'0000-00-00 00:00:00'),(21,'SDN PENANGGAL 03','Krajan, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.139213268220319',' 113.03927718468508 ',0,'0000-00-00 00:00:00'),(22,'SDN PENANGGAL 04','R2XR+J3W, Krajan, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.1508882630985',' 113.04027604497149 ',0,'0000-00-00 00:00:00'),(23,'SDN PENANGGAL 05','V28Q+XC6, Jalan, Gn. Gending, Penanggal, Candipuro, Lumajang Regency, East Java 67373',' -8.13199108347628',' 113.03839742018567 ',0,'0000-00-00 00:00:00'),(24,'SMP Negeri 2 Candipuro','V23Q+RPW, Watu Kandang, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.14512301628241',' 113.03930355605175 ',0,'0000-00-00 00:00:00'),(25,'Lp. Ma\'arif Nu Mtss Ma\'Arif Nu Roudlotul Musthoea','V25Q+C7C, Watu Kandang, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.141275877157739',' 113.03815403028281 ',0,'0000-00-00 00:00:00'),(26,'SMP, SMA Roudlotul Musthoea','V25P+PCP, Jl. Raya Watukadang, Watu Kandang, Penanggal, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373',' -8.140510327034018',' 113.03605105060836 ',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tbl_evakuasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_info`
--

DROP TABLE IF EXISTS `tbl_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_info` (
  `id_inf` int(11) NOT NULL AUTO_INCREMENT,
  `judul_inf` varchar(1000) NOT NULL,
  `img_inf` varchar(1000) NOT NULL,
  `urai_inf` text NOT NULL,
  `login` varchar(1000) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_inf`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_info`
--

LOCK TABLES `tbl_info` WRITE;
/*!40000 ALTER TABLE `tbl_info` DISABLE KEYS */;
INSERT INTO `tbl_info` VALUES (1,'Si Medic','/asset/semeru.jpg','\r\n<p>SIMEDIC (Sistem Informasi Manajemen Mental, Economic & Disaster) merupakan inisiatif yang dirancang untuk meningkatkan manajemen dan respons Puskesmas Candipuro dalam menghadapi tantangan ekonomi, bencana, dan kesehatan jiwa. Dalam aspek dukungan peningkatan ekonomi, sistem ini menyimpan data tentang kegiatan ekonomi yang menjadi prioritas, seperti industri tambang dan pabrik, serta informasi mengenai peta sebaran ekonomi dan pekerja yang terlibat. Melalui informasi darurat dan basis data pekerja, SIMEDIC dapat menawarkan intervensi yang diperlukan untuk memperkuat ekonomi lokal serta meningkatkan kualitas hidup masyarakat.</p>\r\n<p>Selain itu, SIMEDIC juga berfokus pada penanggulangan bencana dan kesehatan jiwa. Dengan adanya informasi mengenai jenis-jenis bencana dan database warga yang berpotensi terdampak, sistem ini dapat membantu dalam perencanaan dan pelaksanaan strategi evakuasi serta penanganan awal. Dalam bidang kesehatan jiwa, SIMEDIC menawarkan pemantauan kondisi pasien dan akses bagi mereka yang memerlukan dukungan kesehatan mental, lengkap dengan informasi peta wilayah dan tempat penanganan terdekat. Secara keseluruhan, SIMEDIC bertujuan untuk menciptakan ekosistem yang saling mendukung melalui integrasi data dan komunikasi yang efektif, sehingga masyarakat dapat lebih tanggap dan siap menghadapi berbagai tantangan. </p>','1','2024-09-23 02:53:06'),(2,'Call Center','-','<p>Alamat: Jl. Raya Jenderal Soedirman No.94, Krajan, Candipuro, Kec. Candipuro, Kabupaten Lumajang, Jawa Timur 67373.</p>\r\n<p><i class=\"fa fa-phone w3-large\"></i>  <a href=\"tel:+6281233567586\">+62812-3356-7586</a></p>\r\n<p><i class=\"fa fa-globe w3-large\"></i>  <a href=\"https://pkmcandipuro.dinkesp2kb.lumajangkab.go.id\" target=\"_blank\">Website PKM Candipuro Lumajang</a></p>\r\n<p><i class=\"fa fa-envelope w3-large\"></i>  <a href=\"mailto:puskesmas.candipuro@gmail.com\">puskesmas.candipuro@gmail.com</a></p>\r\n<p><i class=\"fa fa-instagram w3-large\"></i>  <a href=\"https://www.instagram.com/puskesmas.candipuro?igsh=bmF4cXJhNHVrdnYy\" target=\"_blank\">puskesmas.candipuro</a></p>\r\n<p><i class=\"fa fa-facebook w3-large\"></i>  <a href=\"https://www.facebook.com/share/iKjr69VZPRwEumM5/?mibextid=qi2Omg\" target=\"_blank\">puskesmascandipuro</a></p>\r\n<p><i class=\"fa fa-youtube w3-large\"></i>  <a href=\"https://youtube.com/@puskesmascandipuro3475?si=QYxv90bhQLirMS1P\" target=\"_blank\">PKM Candipuro Lumajang</a></p>\r\n','1','2024-09-19 01:49:43'),(3,'<b>Kegiatan Prioritas </b>','-','<p>\r\n<h3 > Kegiatan Prioritas Penanggulangan Bencana</h3></p>\r\n<p>\r\n<h3 > Kegiatan Prioritas Peningkatan Ekonomi</h3></p>\r\n<p>\r\n<h3 > Kegiatan Prioritas Kesehatan Jiwa</h3></p>\r\n\r\n\r\n','1','2024-09-11 07:27:20'),(4,'Informasi Kondisi Huntap Huntara','asset/hunta/1.jpeg; asset/hunta/2.jpeg; asset/hunta/3.jpeg; asset/hunta/4.jpeg','     <p>Hunian tetap (Huntap) untuk para penyintas APG Semeru, di bangun di lahan kurang lebih 81 hektare di Desa Sumbermujur ada sekitar 1.951 unit hunian tetap sudah rampung dibangun, secara bertahap akan segera diserahkan kepada masyarakat penyintas bencana, saat ini Huntap telah di huni oleh 445 KK.</p>\r\n                    <p>Kondisi masyarakat di huntap/huntara saat ini sudah bisa kembali beraktifitas normal, ingkat kesehatan masyarakat di huntap/huntara sudah baik dan untuk kondisi air bersih dan kebutuhan lainnya sudah memadai</p>\r\n \r\n<p>Di Kawasan Huntap dan Huntara kini juga telah tersedia Puskesmas Pembantu Mahameru, Puskesmas Pembantu ini adalah sebuah fasilitas kesehatan yang didirikan sebagai upaya untuk memberikan layanan kesehatan yang mudah dijangkau bagi para penyitas Gunung Semeru. Puskesmas Pembantu ini berfungsi sebagai pos kesehatan yang menyediakan layanan medis dasar dan pertolongan pertama pada kasus-kasus darurat di daerah huntap huntara.</p>\r\n\r\n                 ','1','2023-05-30 07:23:51'),(5,'Informasi Ambulan Desa','-','	<p>	<a href=\"tel://082140221721\"> <span style=\'color: #fff;   background-color: #1da39c;   padding: 8px; border-radius: 7px;\' >	Desa Sumbermujur </span></a> </p>\r\n					<p>	<a href=\"tel://085655845223\"><span style=\'color: #fff;   background-color: #1da39c;   padding: 8px; border-radius: 7px;\' >	Desa Penanggal </span></a></p>\r\n					<p>	<a href=\"tel://085536443766\"><span style=\'color: #fff;   background-color: #1da39c;   padding: 8px; border-radius: 7px;\' >	Desa Tambahrejo </span></a></p>\r\n					<p>	<a href=\"tel://085854421990\"><span style=\'color: #fff;   background-color: #1da39c;   padding: 8px; border-radius: 7px;\' >	Desa Kloposawit </span></a></p>\r\n					<p>	<a href=\"tel://085704734357\"><span style=\'color: #fff;   background-color: #1da39c;   padding: 8px; border-radius: 7px;\' >	Desa Tumpeng </span></a></p>\r\n				','','2022-12-05 06:39:51');
/*!40000 ALTER TABLE `tbl_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_keluhan`
--

DROP TABLE IF EXISTS `tbl_keluhan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_keluhan` (
  `id_klh` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(1000) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(1000) NOT NULL,
  `kel` text NOT NULL,
  `lat` varchar(1000) NOT NULL,
  `lng` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_klh`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_keluhan`
--

LOCK TABLES `tbl_keluhan` WRITE;
/*!40000 ALTER TABLE `tbl_keluhan` DISABLE KEYS */;
INSERT INTO `tbl_keluhan` VALUES (2,'3501125503860001','Rina','Penanggal','0812355412xxx','Mau Melahirkan','-8.1368804','113.2236487',1,'2022-09-30 06:42:12'),(6,'3508020107550027','nini','penanggal','08131xxxxx','pusing setiap hari','-8.1368804','113.2236487',0,'2022-09-21 02:44:39'),(7,'3508020201400001','Giman','huntara','081xxxxx','tidak bisa tidur, perut tidak nyaman, pusing','-8.1368804','113.2236487',0,'2022-09-21 02:55:46'),(8,'35080123456789','Rico Irlandie Mayakoda','Huntap blok C2','085755111222','Mengalami pusing dan sesak nafas mulai tadi pagi','-8.1415686','113.0514647',1,'2022-09-30 11:37:12'),(9,'35420521560xxxx','PAINAH','PENANGGAL','081XXXXXXXXX','PUNGGUNG TIDAK BISA LURUS','-8.1368727','113.2236467',0,'2022-09-21 06:01:03'),(10,'3509274911900003','Karima','Huntap','085330924569','Mohon informasi jadwal vaksinasi booster','-8.1447027','113.0438281',0,'2022-09-29 11:02:11'),(19,'3508020607650002','ASMAD','LOKASI HUNTAB DESA SUMBERMUJUR BLOK A1-1','085755152944','saya pusing dan badan terasa panas mulai tadi siang, perut mual mual','-8.1788928','113.0692608',0,'2022-10-06 12:29:40'),(21,'3508052008940002','Ririn ','Penanggal','087751543925','Diare','-8.1338646','113.2236941',0,'2022-10-11 06:52:41'),(22,'3508046401020002','Lyra virna','Dsn kajar kuning 04/09 desa sumbermuluh. Kecamatan candipuro kabupaten lumajang','085895055628','Ngapunten ibu saya mau tanya jadwal imunisasi untuk bulan oktober ini diadakan kapan nggeh . Karena kami sangat membutuhkan kegiatan posyandu di huntap sumbermujur','-8.1043826','113.0263299',0,'2022-10-16 05:34:43'),(23,'3508026803880003','Suniani','Dsn. Curahkoboan 15/06 desa supirurang kecamatan pronojiwo kabupaten lumajang','083111375100','Saya mau tanya jadwal imunisasi bulan oktober ini di huntap khusus curahkoboan kapan iya. Soalnya kami butuh posyandu di huntap ','-8.1043826','113.0263299',0,'2022-10-16 11:09:20'),(24,'3508024407690002','NGATINEM','CORAH KOBOKAN RT.15/RW.06 SUPITURANG PRONIJIWO','082337724282','Pada saat erupsi tgl 4 desember 2022, ibu ngatinem mengungsi di tempeh di rumah saudara kemudian jatuh di kamar mandi sehingga mengalami keluhan tidak bisa jalan, perut dan punggung sakit. Untuk saat ini ibu ngatinem tinggal di rumah anaknya di blok B4-10. Ibu ngatinem minta untuk dilakukan rawat jalan karena tidak ada saudara yang menjaga apabila di rawat inap dan tidak bisa dibonceng dg motor sehingga mohon untuk dilakukan kunjungan rawat jalan di rumah','-8.1293683','113.0176062',0,'2022-12-18 03:55:04');
/*!40000 ALTER TABLE `tbl_keluhan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_login`
--

DROP TABLE IF EXISTS `tbl_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_login` (
  `id_login` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `level` int(11) NOT NULL,
  `jenis` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_login`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_login`
--

LOCK TABLES `tbl_login` WRITE;
/*!40000 ALTER TABLE `tbl_login` DISABLE KEYS */;
INSERT INTO `tbl_login` VALUES (1,1,'pkmcandi','597a6358c7d70157f245179476695840',1,1,'2024-09-11 07:01:53');
/*!40000 ALTER TABLE `tbl_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pasien`
--

DROP TABLE IF EXISTS `tbl_pasien`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pasien` (
  `id_png` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(1000) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `asal` text NOT NULL,
  `jk` varchar(100) NOT NULL,
  `usia` int(11) NOT NULL,
  `golongan` varchar(1000) NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_png`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pasien`
--

LOCK TABLES `tbl_pasien` WRITE;
/*!40000 ALTER TABLE `tbl_pasien` DISABLE KEYS */;
INSERT INTO `tbl_pasien` VALUES (1,'\'3508154704920001','Qudrotun Khasanah','Jl Masjid RT/RW 002/002 Ds. Kebonagung Kec. Sukodono','P',31,'-',0,'0000-00-00 00:00:00'),(2,'\'3508050606820008','Sugiono','Dsn Warkut RT/RW 016/003 Ds. Besuk Kec.Tempeh','L',41,'-',0,'0000-00-00 00:00:00'),(3,'\'3508211605960001','Robby Afandi','Dsn Jurang Dawir RT/RW 025/004 Ds Mojosari','L',27,'-',0,'0000-00-00 00:00:00'),(4,'\'3508032808960004','Hansa','Dsn krajan 2 rt/rw 040/014 Ds. Selok awar-awar KecPasirian','L',27,'-',0,'0000-00-00 00:00:00'),(5,'\'3508120107800142','Karto','Dsn pusung duwur 002/007 Ds. argosari Kec. Senduro','L',45,'-',0,'0000-00-00 00:00:00'),(6,'\'3508033103930001','Sapta Doni Wijaya','Dsn Rekesan 001/004 Ds Tambahrejo Candipuro','L',30,'-',0,'0000-00-00 00:00:00'),(7,'\'3508032006960002','Roviul Hasan','Dsn Krajan 042/005 Ds. Jarit Kec. Candipuro','L',27,'-',0,'0000-00-00 00:00:00'),(8,'‘1406156311840003','Rina Purwati','Dsn Kajar Kuning 001/009 Sumberwuluh','P',39,'-',0,'0000-00-00 00:00:00'),(9,'\'3508041606610004','Yasiaman','Dsn Basuki 002/001 Desa Nguter Kec. Pasirian','L',62,'-',0,'0000-00-00 00:00:00'),(10,'\'3508054703810001','Nur Khasanah Wahyuning','Dsn. Kampung Baru 031/004  Ds. Tempeh Tengah','P',42,'-',0,'0000-00-00 00:00:00'),(11,'‘3578110609870003','Moch. Gufron','Dsn. Uranggantung 072/010 Ds Jarit Candipuro','L',36,'-',0,'0000-00-00 00:00:00'),(12,'‘1406156311840003','Rina Purwati','Dsn Kajar Kuning 001/009 Sumberwuluh','P',39,'-',0,'0000-00-00 00:00:00'),(13,'\'3508210210930003','M. Abdul Majid','Dsn Gedongsari 56/08 Labruk Kidul kec. Sumbersuko','L',30,'-',0,'0000-00-00 00:00:00'),(14,'\'3508100506840001','Subhan','Dsn Wunguan 003/003 Kencong Jember','L',39,'-',0,'0000-00-00 00:00:00'),(15,'\'3508033103930001','Sapta Doni Wijaya','Dsn Rekesan 001/004 Ds Tambahrejo Candipuro','L',30,'-',0,'0000-00-00 00:00:00'),(16,'\'3508033103930001','Sapta Doni Wijaya','Dsn Rekesan 001/004 Ds Tambahrejo Candipuro','L',30,'-',0,'0000-00-00 00:00:00'),(17,'-','Dwi','Wlingi Blitar','L',40,'-',0,'0000-00-00 00:00:00'),(18,'-','Solekhudin','Pasirian','L',34,'-',0,'0000-00-00 00:00:00'),(19,'‘3310040902220007','Maryono','Ds Wiro 017/006 Kec Bayat Klaten Jawa Tengah','L',43,'-',0,'0000-00-00 00:00:00'),(20,'‘3204250505030015','Wahyu Gunawan','KP. Bojong Asih 004/008 Ds Cicalengka Wetan Kec Cicalengka Bandung Jawa Barat','L',20,'-',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tbl_pasien` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_peduli`
--

DROP TABLE IF EXISTS `tbl_peduli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_peduli` (
  `id_pdl` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(1000) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(1000) NOT NULL,
  `info` text NOT NULL,
  `jenis` int(11) NOT NULL,
  `nilai` varchar(1000) NOT NULL,
  `pub` int(11) NOT NULL,
  `lat` varchar(1000) DEFAULT NULL,
  `lng` varchar(1000) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_pdl`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_peduli`
--

LOCK TABLES `tbl_peduli` WRITE;
/*!40000 ALTER TABLE `tbl_peduli` DISABLE KEYS */;
INSERT INTO `tbl_peduli` VALUES (1,'35081xxxxxxxxxxx','supeno','penanggal','081xxxxxx','ada nasbung 50 bungkus untuk para pengungsi',2,'',0,'-8.136879','113.2236452',0,'2022-09-21 04:12:43'),(2,'35011212xxxxxxxx','Sugi','penanggal','08122xxxxxx','nasi kotak 20 biji',2,'500000',1,'-8.136875','113.2236525',0,'2022-10-03 07:07:54'),(3,'3508031809890001','Misdiono','Huntap blok A5-6','08123456789','Membutuhkan selimut dan kipas angin',2,'500000',0,'-8.1412466','113.2336401',1,'2022-10-03 07:09:34'),(13,'198704252005041003','Areh','Bogor','085749594441','Ada bantuan dari bu areh 500rb untuk penyntas Apg',2,'500000',1,'-8.137011','113.2340444',0,'2022-10-14 00:14:02'),(14,'3508026001980003','Rosela wardani L. M','Curahkoboan, supiturang, pronojiwo','082338370098','Kapan pelaksanaan posyandu di huntap sumbermujur min',1,'',0,'-8.1444733','113.0423389',0,'2022-10-15 14:21:00'),(15,'3508026001980003','Rosela wardani l. M','Curahkoboan, supiturang, pronojiwo','082338370098','Kapan pelaksanaan posyandu di huntap min',1,'',0,'-8.1461768','113.0418437',0,'2022-11-16 07:10:30');
/*!40000 ALTER TABLE `tbl_peduli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pekerja`
--

DROP TABLE IF EXISTS `tbl_pekerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pekerja` (
  `id_png` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(1000) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `asal` text NOT NULL,
  `jk` varchar(100) NOT NULL,
  `usia` varchar(100) NOT NULL,
  `golongan` varchar(1000) NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_png`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pekerja`
--

LOCK TABLES `tbl_pekerja` WRITE;
/*!40000 ALTER TABLE `tbl_pekerja` DISABLE KEYS */;
INSERT INTO `tbl_pekerja` VALUES (1,'xx','KARYANTO','KAMAR KAJANG','L','-','-',0,'0000-00-00 00:00:00'),(2,'xx','NGATMARI','SUMBERWULUH','L','-','-',0,'0000-00-00 00:00:00'),(3,'xx','KIMPUL','SUMBERWULUH','L','-','-',0,'0000-00-00 00:00:00'),(4,'xx','MISNI','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(5,'xx','ALI','SUMBERWULUH TENGAH','L','-','-',0,'0000-00-00 00:00:00'),(6,'xx','PARNI','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(7,'xx','H.SUKO','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(8,'xx','J.SAIUL','KAMAR KAJANG','L','-','-',0,'0000-00-00 00:00:00'),(9,'xx','SLAMET','KAMAR KAJANG','L','-','-',0,'0000-00-00 00:00:00'),(10,'xx','JEMAIN','SUMBERWULUH','L','-','-',0,'0000-00-00 00:00:00'),(11,'xx','AYU','KRAJAN','P','-','-',0,'0000-00-00 00:00:00'),(12,'xx','HASIM','SUMBERWULUH TENGAH','L','-','-',0,'0000-00-00 00:00:00'),(13,'xx','GIYAS','KAMPUNG RENTENG','L','-','-',0,'0000-00-00 00:00:00'),(14,'xx','BANDRI','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(15,'xx','PONIMAN','KEBONDELLI SELATAN','L','-','-',0,'0000-00-00 00:00:00'),(16,'xx','SAMSUDIN','KAMAR KAJANG','L','-','-',0,'0000-00-00 00:00:00'),(17,'xx','NURSALIM','SUMBERWULUH','L','-','-',0,'0000-00-00 00:00:00'),(18,'xx','KUMBANH','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(19,'xx','HADI','SUMBERWULUH TENGAH','L','-','-',0,'0000-00-00 00:00:00'),(20,'xx','ROHIM','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(21,'xx','ADI','KRAJAN','L','-','-',0,'0000-00-00 00:00:00'),(22,'xx','KARNO','KAMAR KAJANG','L','-','-',0,'0000-00-00 00:00:00'),(23,'xx','NANANG','KAMAR KAJANG','L','-','-',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tbl_pekerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pengungsi`
--

DROP TABLE IF EXISTS `tbl_pengungsi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pengungsi` (
  `id_png` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(1000) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `asal` text NOT NULL,
  `jk` varchar(100) NOT NULL,
  `usia` varchar(100) NOT NULL,
  `golongan` varchar(1000) NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_png`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pengungsi`
--

LOCK TABLES `tbl_pengungsi` WRITE;
/*!40000 ALTER TABLE `tbl_pengungsi` DISABLE KEYS */;
INSERT INTO `tbl_pengungsi` VALUES (1,'3508030508850013','SISWANTO','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-08-1985','-',0,'0000-00-00 00:00:00'),(2,'3509302801940007','AHMAD FAKIH','SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:-,Telp:-','Laki-laki','28-01-1994','-',0,'0000-00-00 00:00:00'),(3,'3508030207950002','SAHRI ROMADONA','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','25-07-1996','-',0,'0000-00-00 00:00:00'),(4,'3508030402790001','BUDI HARIONO','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-05-1976','-',0,'0000-00-00 00:00:00'),(5,'3508032001800002','MARNITO','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','20-01-1980','-',0,'0000-00-00 00:00:00'),(6,'3508030107840085','HIDAYAT','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-07-1984','-',0,'0000-00-00 00:00:00'),(7,'3508033009980002','EKO WIDODO','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','30-09-1998','-',0,'0000-00-00 00:00:00'),(8,'3275051010800074','SAMSUL AG','DUSUN SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','10-10-1980','-',0,'0000-00-00 00:00:00'),(9,'3508031804400003','SIONO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','18-04-1940','-',0,'0000-00-00 00:00:00'),(10,'3527042706910008','MUHAJIR','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:-,Telp:-','Laki-laki','27-06-1991','-',0,'0000-00-00 00:00:00'),(11,'3508035209720007','WARSINAH','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','12-09-1972','-',0,'0000-00-00 00:00:00'),(12,'3508030406900007','JONI WIDJANARKO IRAWAN','DSN SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-06-1990','-',0,'0000-00-00 00:00:00'),(13,'3508037010670006','SALITI','DSN. SUMBER LANGSEP  TELP :-,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','30-10-1967','-',0,'0000-00-00 00:00:00'),(14,'3508031508460002','HADORIH','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-08-1946','-',0,'0000-00-00 00:00:00'),(15,'3508031508760003','MULYADI','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-08-1976','-',0,'0000-00-00 00:00:00'),(16,'3508032406770004','SURYADI','DSN SUMBER LANGSEP,RT:022,RW:006,Dusun:SUMBER LANGSEP,Kodepos:67373,Telp:-','Laki-laki','24-06-1977','-',0,'0000-00-00 00:00:00'),(17,'3314101907820002','TEDDY YULISTIAN','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','19-07-1982','-',0,'0000-00-00 00:00:00'),(18,'3508031605860006','DAVID EFENDI','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','16-05-1986','-',0,'0000-00-00 00:00:00'),(19,'3508030410820003','ABDUL ROHIM','DSN SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-10-1982','-',0,'0000-00-00 00:00:00'),(20,'3508031008800002','M.H.D. KOSIM','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','10-08-1980','-',0,'0000-00-00 00:00:00'),(21,'3508031808930008','PRIYO LAKSONO','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','18-08-1993','-',0,'0000-00-00 00:00:00'),(22,'3508030501600002','SENEMAN','SUMBER LANGSEP TELP :-,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-01-1960','-',0,'0000-00-00 00:00:00'),(23,'3508032412720002','PAIMUN','DSN SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','24-12-1972','-',0,'0000-00-00 00:00:00'),(24,'3508030506950011','ISWANTO','DSN. SUMBER LANGSEP ,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-06-1995','-',0,'0000-00-00 00:00:00'),(25,'3508032606040005','AGUS PURWANTO','DSN. SUMBERLANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','26-06-2004','-',0,'0000-00-00 00:00:00'),(26,'3508030807820004','EKO WIDODO','DSN. SUMBER LANGSEP,RT:021,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','08-07-1982','-',0,'0000-00-00 00:00:00'),(27,'3508031201980012','NUR HASAN BASRI','SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-01-1998','-',0,'0000-00-00 00:00:00'),(28,'3508031206860008','MATRUJI','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-06-1986','-',0,'0000-00-00 00:00:00'),(29,'3508030508760005','ANSORI','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-08-1976','-',0,'0000-00-00 00:00:00'),(30,'3508032802880007','SUNANDAR','DSN. SUMBER LANGSEP ,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','28-02-1988','-',0,'0000-00-00 00:00:00'),(31,'3508030601880004','ARIFIN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','06-01-1988','-',0,'0000-00-00 00:00:00'),(32,'3508030107890019','AAN ISWAHYUDI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-07-1989','-',0,'0000-00-00 00:00:00'),(33,'3508031010530007','SENAMEN','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','10-10-1953','-',0,'0000-00-00 00:00:00'),(34,'3508032803520002','RAHMAT','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','28-03-1952','-',0,'0000-00-00 00:00:00'),(35,'3508030706840002','SUHARTONO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','07-06-1984','-',0,'0000-00-00 00:00:00'),(36,'3508030906800006','MOH. ZAINI','DSN SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','06-06-1980','-',0,'0000-00-00 00:00:00'),(37,'3508030809820006','MUHLISIN','DSN. SUMBER LANGSEP ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-06-1983','-',0,'0000-00-00 00:00:00'),(38,'3510201512850003','MANSUR','DUSUN SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-12-1985','-',0,'0000-00-00 00:00:00'),(39,'3508040412870003','DEDY ABDUL ROKHIM','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-12-1987','-',0,'0000-00-00 00:00:00'),(40,'3508031201780012','DUR ROHIM','DSN.SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-01-1978','-',0,'0000-00-00 00:00:00'),(41,'3508031803910002','ZAENAL ABIDIN','DSN. SUMBER LANGSEP  TELP :-,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','10-01-1991','-',0,'0000-00-00 00:00:00'),(42,'3508031003900005','NUR HASAN','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','10-03-1990','-',0,'0000-00-00 00:00:00'),(43,'3508030810870003','SUDIONO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','08-10-1987','-',0,'0000-00-00 00:00:00'),(44,'3508031502780009','MAYAR','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-02-1978','-',0,'0000-00-00 00:00:00'),(45,'3508033006570079','NGASERI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','30-06-1957','-',0,'0000-00-00 00:00:00'),(46,'3509031507790002','ARIFIN','DUSUN SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-07-1979','-',0,'0000-00-00 00:00:00'),(47,'3508031204910005','M. ARIFIN','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-04-1991','-',0,'0000-00-00 00:00:00'),(48,'3508036905850001','PAINEM','DSN. SUMBERLANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','29-05-1985','-',0,'0000-00-00 00:00:00'),(49,'3508034705900003','RODIYAH','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','07-05-1990','-',0,'0000-00-00 00:00:00'),(50,'3508034301680003','ATMANI','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','03-01-1968','-',0,'0000-00-00 00:00:00'),(51,'3508030805400001','TIMAN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','08-05-1940','-',0,'0000-00-00 00:00:00'),(52,'3508030210630004','LAMIDI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-10-1963','-',0,'0000-00-00 00:00:00'),(53,'3508032009810001','DIDIK HARIONO','DSN. SUMBER LANGSEP ,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','20-09-1981','-',0,'0000-00-00 00:00:00'),(54,'3508030207520002','PONIMAN','DSN. SUMBER LANGSEP ,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-07-1952','-',0,'0000-00-00 00:00:00'),(55,'3508036608650002','RASMIATI','DSN. SUMBER LANGSEP  ,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','26-08-1965','-',0,'0000-00-00 00:00:00'),(56,'3508030308680001','SUPOYO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','03-08-1968','-',0,'0000-00-00 00:00:00'),(57,'3508030807500006','BUNARI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','08-07-1950','-',0,'0000-00-00 00:00:00'),(58,'3508035206350001','PONITRI','DSN. SUMBERLANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','12-06-1935','-',0,'0000-00-00 00:00:00'),(59,'3508030505650005','SUPARDI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-05-1965','-',0,'0000-00-00 00:00:00'),(60,'3508032405600002','HASAN ARUJI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','24-05-1960','-',0,'0000-00-00 00:00:00'),(61,'3508031302780003','M. SANORA','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','13-02-1978','-',0,'0000-00-00 00:00:00'),(62,'3508032404650002','PONIMAN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','24-04-1965','-',0,'0000-00-00 00:00:00'),(63,'3508030308530007','BAKAT','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','03-08-1953','-',0,'0000-00-00 00:00:00'),(64,'3508030407790003','SANUSI','DSN.SUMBER LANGSEP,RT:022,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-07-1979','-',0,'0000-00-00 00:00:00'),(65,'3508030203490001','SAIMAN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-03-1949','-',0,'0000-00-00 00:00:00'),(66,'3508030104300002','SAMENUN','SUMBERLANGSEP  TELP :-,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-04-1930','-',0,'0000-00-00 00:00:00'),(67,'3508034605590002','BATI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','06-05-1959','-',0,'0000-00-00 00:00:00'),(68,'3508032707890011','AGUS YULIANTO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','27-07-1989','-',0,'0000-00-00 00:00:00'),(69,'3508030110760008','LAPDIONO','DSN. SUMBER LANGSEP ,RT:021,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-10-1976','-',0,'0000-00-00 00:00:00'),(70,'3508030712750004','SIYONO','DSN. SUMBER LANGSEP,RT:021,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','07-12-1975','-',0,'0000-00-00 00:00:00'),(71,'3508031106620002','HADIN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-06-1962','-',0,'0000-00-00 00:00:00'),(72,'3508033103790004','ASMAT','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-09-1976','-',0,'0000-00-00 00:00:00'),(73,'3508032106610002','SUPENO','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','21-06-1961','-',0,'0000-00-00 00:00:00'),(74,'3508034606720005','SIHNARTI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','07-11-1974','-',0,'0000-00-00 00:00:00'),(75,'3508030408620004','TUKIMAN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-08-1962','-',0,'0000-00-00 00:00:00'),(76,'3508030103520006','SUTAMAN','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-03-1952','-',0,'0000-00-00 00:00:00'),(77,'3508032701750001','LASMADI','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','27-01-1975','-',0,'0000-00-00 00:00:00'),(78,'3508031907520003','DURASMAN','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','19-07-1952','-',0,'0000-00-00 00:00:00'),(79,'3508030105660003','SUMIDI','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-05-1966','-',0,'0000-00-00 00:00:00'),(80,'3508031607670009','ABDULLAH','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','16-07-1967','-',0,'0000-00-00 00:00:00'),(81,'3508036311520001','MULIFAH','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','23-11-1952','-',0,'0000-00-00 00:00:00'),(82,'3508034104500009','PONITI','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','01-04-1950','-',0,'0000-00-00 00:00:00'),(83,'3508030305650002','AWALI','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','03-05-1965','-',0,'0000-00-00 00:00:00'),(84,'3508030708650006','BUARI','DSN. SUMBER LANGSEP  ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','07-08-1965','-',0,'0000-00-00 00:00:00'),(85,'3508030105520001','SURAHMA','DSN. SUMBER LANGSEP ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-05-1952','-',0,'0000-00-00 00:00:00'),(86,'3508033010530001','MISNAJI','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','30-10-1953','-',0,'0000-00-00 00:00:00'),(87,'3508030203780003','HERMAN','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-03-1978','-',0,'0000-00-00 00:00:00'),(88,'3508034104630049','HABIYE','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','01-04-1949','-',0,'0000-00-00 00:00:00'),(89,'3508035002430002','SALNA','SUMBERLANGSEP  TELP :-,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','10-02-1943','-',0,'0000-00-00 00:00:00'),(90,'3508031505610008','SANIMIN','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-05-1961','-',0,'0000-00-00 00:00:00'),(91,'3508030809760006','PAIDI','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','16-05-1979','-',0,'0000-00-00 00:00:00'),(92,'3508030207450004','RIRIMIN','SUMBERLANGSEP  TELP :-,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-07-1945','-',0,'0000-00-00 00:00:00'),(93,'3508031104490002','PONIRAN','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-04-1949','-',0,'0000-00-00 00:00:00'),(94,'3508030709600008','JUMALI','DSN. SUMBER LANGSEP  TELP :-,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','07-09-1960','-',0,'0000-00-00 00:00:00'),(95,'3508030205650004','SADIN','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-05-1965','-',0,'0000-00-00 00:00:00'),(96,'3508031107630002','MOH HOSAIN','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-07-1963','-',0,'0000-00-00 00:00:00'),(97,'3508031208630005','MATNAJI','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-10-1953','-',0,'0000-00-00 00:00:00'),(98,'3508030104570005','GANGSAR','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-04-1957','-',0,'0000-00-00 00:00:00'),(99,'3508030105610001','LANJAR','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-05-1961','-',0,'0000-00-00 00:00:00'),(100,'3508031204720008','SURIP','DSN.SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','07-11-1975','-',0,'0000-00-00 00:00:00'),(101,'3508033110780001','KLIWON','DSN. SUMBER LANGSEP  ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','31-10-1978','-',0,'0000-00-00 00:00:00'),(102,'3508030311850003','HOLILI','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','03-11-1985','-',0,'0000-00-00 00:00:00'),(103,'3508031104690005','SUJARNO','DSN. SUMBER LANGSEP ,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-04-1969','-',0,'0000-00-00 00:00:00'),(104,'3508031808880005','ANTON WIDODO','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','18-08-1988','-',0,'0000-00-00 00:00:00'),(105,'3508034104320001','NAIYA','DSN SUMBER LANGSEP  TELP :-,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','01-04-1932','-',0,'0000-00-00 00:00:00'),(106,'3508034701550001','SUPINI','SUMBERLANGSEP  TELP :-,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','07-01-1955','-',0,'0000-00-00 00:00:00'),(107,'3508030403450004','MAT DAHRI','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-03-1945','-',0,'0000-00-00 00:00:00'),(108,'3508030201700004','SUKUR ADI PURNOMO','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-01-1970','-',0,'0000-00-00 00:00:00'),(109,'3508030808800011','ERI SUKAESIH MASDA','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:SUMBER LANGSEP,Kodepos:67373,Telp:-','Laki-laki','08-08-1980','-',0,'0000-00-00 00:00:00'),(110,'3508031709760003','SUTRISNO','DSN. SUMBER LANGSEP,RT:021,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','17-09-1976','-',0,'0000-00-00 00:00:00'),(111,'3508031906890003','MOH. AMIN','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:DSN. SUMBER LANGSEP,Kodepos:67373,Telp:-','Laki-laki','19-06-1989','-',0,'0000-00-00 00:00:00'),(112,'3508034401590001','SAGINTEN','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:SUMBER LANGSEP,Kodepos:67373,Telp:-','Perempuan','04-01-1959','-',0,'0000-00-00 00:00:00'),(113,'3503132503730001','MUHSIN','DSN SUMBER LANGSEP,RT:021,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','25-03-1973','-',0,'0000-00-00 00:00:00'),(114,'3508031706820008','SUKIMAN','DSN. SUMBER LANGSEP,RT:018,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','17-06-1982','-',0,'0000-00-00 00:00:00'),(115,'3508034209780003','SUTIK','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','02-09-1978','-',0,'0000-00-00 00:00:00'),(116,'3508030104850001','ALI SUTOPO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-04-1985','-',0,'0000-00-00 00:00:00'),(117,'3508030702890008','SAIFUL ULUM','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','07-02-1989','-',0,'0000-00-00 00:00:00'),(118,'3508020101960004','NOVAL AFGAN','SUMBERLANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','01-01-1996','-',0,'0000-00-00 00:00:00'),(119,'3508030407710006','TOHARI','DSN. SUMBER LANGSEP ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-07-1982','-',0,'0000-00-00 00:00:00'),(120,'3508032208850006','RUDI HARTONO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','22-08-1985','-',0,'0000-00-00 00:00:00'),(121,'3508031512790007','SABIK UDIN','DSN SUMBER LANGSEP  TELP :-,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-12-1979','-',0,'0000-00-00 00:00:00'),(122,'3508030405950002','ARYS PRASTYO','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-05-1995','-',0,'0000-00-00 00:00:00'),(123,'3508030405890002','HARIYANTO','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-05-1989','-',0,'0000-00-00 00:00:00'),(124,'3508031202720011','SUYITNO','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-02-1972','-',0,'0000-00-00 00:00:00'),(125,'3508031209840004','SATUMAN','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-09-1984','-',0,'0000-00-00 00:00:00'),(126,'3508031901810003','IMAM SAFI\'I','DSN. SUMBER LANGSEP ,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','19-01-1981','-',0,'0000-00-00 00:00:00'),(127,'3508031912650007','KARIYANTO','DSN. SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','19-12-1965','-',0,'0000-00-00 00:00:00'),(128,'3508034304450004','MURI','DSN. SUMBER LANGSEP,RT:022,RW:006,Dusun:-,Kodepos:67373,Telp:-','Perempuan','03-04-1945','-',0,'0000-00-00 00:00:00'),(129,'3508031106810001','NUR CHASAN','DSN SUMBER LANGSEP,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-06-1981','-',0,'0000-00-00 00:00:00'),(130,'3508030504830011','MARNO','DSN. SUMBER LANGSEP,RT:025,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-02-1981','-',0,'0000-00-00 00:00:00'),(131,'3508031503810004','SUMAJI','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-03-1981','-',0,'0000-00-00 00:00:00'),(132,'3508032002880009','DICKI DIANTORO','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','20-02-1988','-',0,'0000-00-00 00:00:00'),(133,'3508031705590001','SUGIMAN','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','17-05-1959','-',0,'0000-00-00 00:00:00'),(134,'3508031611880002','TOHIRON','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','16-11-1988','-',0,'0000-00-00 00:00:00'),(135,'3508031111820004','SUYOTO','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','11-11-1982','-',0,'0000-00-00 00:00:00'),(136,'3508032005520001','MATBAHRI','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','20-05-1952','-',0,'0000-00-00 00:00:00'),(137,'3508030207810006','ABANG JAMBANG','DSN. SUMBER LANGSEP  ,RT:023,RW:006,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','02-07-1981','-',0,'0000-00-00 00:00:00'),(138,'3508036305570001','YATINI','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','23-05-1957','-',0,'0000-00-00 00:00:00'),(139,'3508031211540004','SUPRAYITNO','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-11-1954','-',0,'0000-00-00 00:00:00'),(140,'3508030510720008','SUGIANTO','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-10-1972','-',0,'0000-00-00 00:00:00'),(141,'3508031510860004','DARMADI','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','15-10-1986','-',0,'0000-00-00 00:00:00'),(142,'3508031203460003','PAIDI','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','12-03-1946','-',0,'0000-00-00 00:00:00'),(143,'3508030405640002','MARIDI','DSN SUMBER KAJAR,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','04-05-1964','-',0,'0000-00-00 00:00:00'),(144,'3508030508710003','MARKASAN','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','05-08-1971','-',0,'0000-00-00 00:00:00'),(145,'3508030910920003','PUJIONO','DSN. SUMBER KAJAR ,RT:018,RW:004,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','09-10-1992','-',0,'0000-00-00 00:00:00'),(146,'3508032412890006','FIGUR MAYUDAH','DSN. SUMBER KAJAR,RT:030,RW:011,Dusun:-,Kodepos:67373,Telp:-','Laki-laki','24-12-1989','-',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `tbl_pengungsi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_relawan`
--

DROP TABLE IF EXISTS `tbl_relawan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_relawan` (
  `id_rl` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(100) NOT NULL,
  `nama` varchar(1000) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `alamat` varchar(1000) NOT NULL,
  `telp` varchar(1000) NOT NULL,
  `jangkauan` varchar(1000) NOT NULL,
  `foto` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_rl`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_relawan`
--

LOCK TABLES `tbl_relawan` WRITE;
/*!40000 ALTER TABLE `tbl_relawan` DISABLE KEYS */;
INSERT INTO `tbl_relawan` VALUES (1,'','Yayuk Sri Rahayu','Kepala Desa','Dsn Sidorejo Desa Sumbermujur Candipuro','081333929872','500m','',1,1,'2022-09-30 11:55:24'),(2,'','Tarimin','Ketua','Candipuro','081295818315','','',1,0,'2022-09-29 07:05:40'),(3,'','Eko Supriyanto','Sekretaris','Candipuro','081230901498','','',1,0,'2022-09-29 07:05:40'),(4,'','Ida Nur Hayati','Bendahara','Candipuro','082229350254','','',1,0,'2022-09-29 07:05:40'),(5,'','Agus Wijaya','Humas','Candipuro','081331435272','','',1,0,'2022-09-29 07:05:40'),(6,'','Ainul Kholiliyah','Logistik','Candipuro','082229394350','','',1,0,'2022-09-29 07:05:40'),(7,'','Vivi Halisah Dewi','Dapur Umum','Candipuro','082335620605','','',1,0,'2022-09-29 07:05:40'),(8,'','Syaidin','Penanganan Pengungsi','Candipuro','082333430709','','',1,0,'2022-09-29 07:05:40'),(9,'','Gatot Supriyadi','SAR dan Evakuasi','Candipuro','085259112261','','',1,0,'2022-09-29 07:05:40'),(10,'','Kasimin','Transportasi','Candipuro','082140221721','','',1,0,'2022-09-29 07:05:40'),(11,'','Nita Purwati','Pendidikan','Candipuro','085719630195','','',1,0,'2022-09-29 07:05:40'),(12,'','Lukman','Psikososial','Candipuro','082331335293','','',1,0,'2022-09-29 07:05:40'),(13,'','Turmudzi','Keamanan','Candipuro','085319394209','','',1,0,'2022-09-29 07:05:40'),(14,'','Rudi Mulyono','Air dan Sanitasi','Candipuro','082234695695','','',1,0,'2022-09-29 07:05:40'),(21,'3508031204940000','Adam','Dapur Umum','Dsn Krajan RT01 RW05 Desa Sumbewuluh Candipuro','08123456789','Desa Penanggal','asset/upload/relawan/2t7RRx82oT.jpg',0,0,'2022-10-03 07:47:30'),(23,'3508020601910002','Karina Anggi','Kesehatan','Dsn Krajan Desa Sumbermujur','085746649968','500m','asset/upload/relawan/B7FtfIrYPX.jpeg',0,0,'2022-10-06 12:32:35'),(26,'198704252006041003','Dityatama','Penanganan Pengungsi','Kloposawit Candipuro Lumajang','085749594441','Kloposawit candipuro','',0,0,'2022-10-14 00:17:47');
/*!40000 ALTER TABLE `tbl_relawan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tlkeluhan`
--

DROP TABLE IF EXISTS `tbl_tlkeluhan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tlkeluhan` (
  `id_tkl` int(11) NOT NULL AUTO_INCREMENT,
  `id_klh` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `petugas` varchar(1000) NOT NULL,
  `bukti` text NOT NULL,
  `ket` text NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_tkl`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tlkeluhan`
--

LOCK TABLES `tbl_tlkeluhan` WRITE;
/*!40000 ALTER TABLE `tbl_tlkeluhan` DISABLE KEYS */;
INSERT INTO `tbl_tlkeluhan` VALUES (5,2,'2022-09-30','13:41:09','fita irma','asset/upload/tlkeluhan/PGDFebowue.jpeg','sudah diantarkan ke pkm penanggal',1,'2022-09-30 11:36:20'),(6,8,'2022-09-30','18:36:20','fita irma','asset/upload/tlkeluhan/IifxWdesNu.jpg','sudah dilakukan terapi dan observasi terhadap pasien',1,'2022-09-30 11:37:12');
/*!40000 ALTER TABLE `tbl_tlkeluhan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tlpeduli`
--

DROP TABLE IF EXISTS `tbl_tlpeduli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tlpeduli` (
  `id_tpd` int(11) NOT NULL AUTO_INCREMENT,
  `id_pdl` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `petugas` varchar(1000) NOT NULL,
  `bukti` text NOT NULL,
  `ket` text NOT NULL,
  `login` int(11) NOT NULL,
  `log` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_tpd`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tlpeduli`
--

LOCK TABLES `tbl_tlpeduli` WRITE;
/*!40000 ALTER TABLE `tbl_tlpeduli` DISABLE KEYS */;
INSERT INTO `tbl_tlpeduli` VALUES (2,3,'2022-10-03','14:07:57','Fulan','asset/upload/tlpeduli/671QyKaSMk.jpg','Selimut telah di antar ke yang bersangkutan.',1,'2022-10-03 07:09:34');
/*!40000 ALTER TABLE `tbl_tlpeduli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'admin_simedic'
--

--
-- Dumping routines for database 'admin_simedic'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-17  9:29:44
