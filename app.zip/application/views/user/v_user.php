<header class="w3-container w3-padding-32 w3-center w3-white" id="home">
<center> <a href="" ><img src="/asset/simedic.png" loading="lazy" class="img-fluid" width='50%'></a></center>
  <h1 class="w3-jumbo"><span class="w3-hide-small">SI MEDIC</span></h1>
  <h2>Selamat Datang di Admin
   <center>
   <img src="/asset/logolmj.png" loading="lazy" class="img-fluid" width="20%">
   <img src="/asset/logopkmp.png" loading="lazy" class="img-fluid" width="20%">
 </center>
</header>
