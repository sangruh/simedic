
    <!-- Footer -->
  <footer class="w3-content w3-padding-64 w3-text-grey w3-xlarge">
    <p class="w3-medium">Puskesmas Candipuro Kab. Lumajang  <a href="<?php echo base_url(); ?>" class="w3-hover-text-green">SI MEDIC</a></p>
    <p class="w3-medium">V. 2024.1</p>
  <!-- End footer -->
  </footer>
<!-- END PAGE CONTENT -->
</div>
